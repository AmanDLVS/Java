/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_amancio_interfaz;

/**
 *
 * @author amanc
 */
public class Ciudad {
    private String nombre_ciudad;
    private String nombre_pais;
    
    Ciudad(String nc,String np){
    this.nombre_ciudad=nc;
    this.nombre_pais=np;
    }

    public String getNombre_ciudad() {
        return nombre_ciudad;
    }

    public void setNombre_ciudad(String nombre_ciudad) {
        this.nombre_ciudad = nombre_ciudad;
    }

    public String getNombre_pais() {
        return nombre_pais;
    }

    public void setNombre_pais(String nombre_pais) {
        this.nombre_pais = nombre_pais;
    }


}
