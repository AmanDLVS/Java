/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_amancio_interfaz;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 *
 * @author amanc
 */
public class Partido extends Clubfutbol {

    private int num_partido;
    private String n_equiplocal;
    private String n_equipvisit;
    private LocalDate fecha;
    private LocalTime hora;
    // private ArrayList<Partido> primera_ronda;
    private ArrayList<Clubfutbol> segunda_ronda;
    private ArrayList<Clubfutbol> tercera_ronda;
    private ArrayList<Clubfutbol> final_ronda;

    Partido() {
        this.num_partido = 0;
        this.n_equiplocal = "";
        this.n_equipvisit = "";
        this.fecha = LocalDate.now();
        this.hora = LocalTime.now();
        // primera_ronda = new ArrayList<Partido>();
        this.segunda_ronda = new ArrayList<Clubfutbol>();
        this.tercera_ronda = new ArrayList<Clubfutbol>();
        this.final_ronda = new ArrayList<Clubfutbol>();
    }

    Partido(String local, String visit) {
        super();
        this.num_partido = 0;
        this.n_equiplocal = local;
        this.n_equipvisit = visit;
        this.fecha = LocalDate.now();
        this.hora = LocalTime.now();
    }

    /*
    this.nombre_equipo = "";
        this.ciudad = "";
        this.pais = "";
        this.num_goles = 0;
        this.nombre_estadio = "";
        this.fecha_fundacion = "";
        this.partidos_ganados = 0;
     */
    public void jugarPartido(Clubfutbol a, Clubfutbol b) {
        int rand = (int) (Math.random() * 2);

        if (rand == 1) {
            a.setPartidos_ganados(this.getPartidos_ganados() + 1);
            a.setNum_goles((int) (Math.random() * 9));
            System.out.println("Ha ganado el partido el equipo " + a.getnombre_equipo() + " con " + a.getNum_goles() + " goles.");

            // System.out.println("Equipo 1: "+a.getnombre_equipo()+" con "+a.getPartidos_ganados()+" ganados.");
        } else {
            b.setPartidos_ganados(this.getPartidos_ganados() + 1);
            b.setNum_goles((int) (Math.random() * 9));
            System.out.println("Ha ganado el partido el equipo " + b.getnombre_equipo() + " con " + b.getNum_goles() + " goles.");

//  System.out.println("Equipo 2: "+b.getnombre_equipo()+" con "+b.getPartidos_ganados()+" ganados.");
        }

    }

    public String getN_equiplocal() {
        return n_equiplocal;
    }

    public void setN_equiplocal(String n_equiplocal) {
        this.n_equiplocal = n_equiplocal;
    }

    public String getN_equipvisit() {
        return n_equipvisit;
    }

    public void setN_equipvisit(String n_equipvisit) {
        this.n_equipvisit = n_equipvisit;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public int getNum_partido() {
        return num_partido;
    }

    public void setNum_partido(int num_partido) {
        this.num_partido = num_partido;
    }

    public ArrayList<Clubfutbol> getSegunda_ronda() {
        return segunda_ronda;
    }

    public void setSegunda_ronda(ArrayList<Clubfutbol> segunda_ronda) {
        this.segunda_ronda = segunda_ronda;
    }

    public ArrayList<Clubfutbol> getTercera_ronda() {
        return tercera_ronda;
    }

    public void setTercera_ronda(ArrayList<Clubfutbol> tercera_ronda) {
        this.tercera_ronda = tercera_ronda;
    }

    public ArrayList<Clubfutbol> getFinal_ronda() {
        return final_ronda;
    }

    public void setFinal_ronda(ArrayList<Clubfutbol> final_ronda) {
        this.final_ronda = final_ronda;
    }

}
