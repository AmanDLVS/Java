/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_amancio_interfaz;

import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author amanc
 */
public class Liga implements Serializable{

    private String nombrelig;
    private int numequip;
    private ArrayList<Clubfutbol> listae;
    private Scanner sc = new Scanner(System.in);
    private String Ganador;
    private ArrayList<Arbitraje> lista_arbitraje;
    private ArrayList<CiudadPartido> Ciudad_part;
    private ArrayList<Clubfutbol> ganadores1;
    private ArrayList<Clubfutbol> ganadores2;
    
    Liga() {
        super();
        this.nombrelig = "";
        this.numequip = 0;
        this.listae = new ArrayList<Clubfutbol>();
        this.lista_arbitraje = new ArrayList<Arbitraje>();
        this.ganadores1 = new ArrayList<Clubfutbol>();
        this.ganadores2 = new ArrayList<Clubfutbol>();
    }

    public void parametrosEquipos(int n) {
        for (int i = 1; i < n + 1; i++) {
            System.out.println("Equipo " + i + ": ");
            Clubfutbol club = new Clubfutbol(i);
            System.out.println("Nombre del equipo: ");
            ///,e salta este set por alguna razon que no se
            club.setnombre_equipo(sc.nextLine());
            System.out.println("Ciudad: ");
            club.setCiudad(sc.nextLine());
            System.out.println("Pais: ");
            club.setPais(sc.nextLine());
            System.out.println("Nombre del estadio: ");
            club.setNombre_estadio(sc.nextLine());
            System.out.println("Fecha de fundacion: ");
            club.setFecha_fundacion(sc.nextLine());
            club.printClub(club);
            listae.add(club);
            System.out.println("Equipo " + i + " añadido.");
        }

    }

    public void crearLiga(File fj, File fn, File fneq, File fc, File fp, File fnes, File ff, int k) {
        int aux = 0, option = 0;
        String c = null;
        aux = k;
        long pos = 0;
        File arbitxt = new File("arbitros_liga_XXX.txt");
        File equips = new File("equipos_jug_XXX.txt");
        File ciudad_liga = new File("ciudades_liga_amanciodelavarasanchez.txt");
        try {
            FileOutputStream perde = new FileOutputStream("equipos_perdedores_liga_amanciodelavarasanchez.dat");
            DataOutputStream perdedordata = new DataOutputStream(perde); 
            FileWriter escribirarbi = new FileWriter(arbitxt);
            BufferedWriter escribirarbitro = new BufferedWriter(escribirarbi);
            FileWriter escribirequips = new FileWriter(equips);
            BufferedWriter escribirequipos = new BufferedWriter(escribirequips);
            FileWriter ciu_lig = new FileWriter(ciudad_liga);
            BufferedWriter escribir_ciu_lig = new BufferedWriter(ciu_lig);
            
           // while (option != 3) {
                //System.out.println("1.Crear Liga Manual.\n2.Crear Liga Random.\n3.Atras");
               // option = sc.nextInt();
              //  switch (option) {
                    //case 1:
                    //    parametrosEquipos(aux);
                     //   option = 3;
                     //   break;
                //    case 2:
                      //  option = 3;*/
                        try {
                            //Para jugadores, nombres y nacionalidades
                            RandomAccessFile archivoj = new RandomAccessFile(fj, "r");
                            RandomAccessFile archivon = new RandomAccessFile(fn, "r");
                            //Para ciudades, nombre equipo, ciudad, pais, nombre estadio, fecha fundacion
                            RandomAccessFile archivoneq = new RandomAccessFile(fneq, "r");
                            RandomAccessFile archivoc = new RandomAccessFile(fc, "r");
                            RandomAccessFile archivop = new RandomAccessFile(fp, "r");
                            RandomAccessFile archivones = new RandomAccessFile(fnes, "r");
                            RandomAccessFile archivof = new RandomAccessFile(ff, "r");

                            // System.out.println("¿Quiere generar usted los equipos manualmente?: \n S/N");
                            //c = sc.nextLine();
                            System.out.println("COMUIENZAN A FICHAR LOS EQUIPOS...");

                            /////////////////////////////////////////////////////////////////////
                            ///FICHA LOS EQUIPOS Y LOS ESCRIBE EN EL FICHERO//////////////////////
                            /////////////////////////////////////////////////////////////////////
                            
                            for (int i = 1; i <= aux; i++) {
                                Clubfutbol club = new Clubfutbol();
                                club.creaEquipoRandom(club, archivoneq, archivoc, archivop, archivones, archivof);
                                club.FicharEquip(archivoj, archivon, pos);
                                club.printClub(club);
                                club.printJugadores();
                                listae.add(club);
                                
                                for (int j = 0; j < listae.size(); j++) {
                                    escribirequipos.write("\n" + listae.get(j).getNombre_equipo()+ "\n-JUGADORES: \n");
                                    for (int l = 1; l < listae.get(j).getJ().size(); l++) {
                                        escribirequipos.write("\n----------------------\n");
                                        escribirequipos.write(listae.get(j).getJ().get(l).getNacionalidad() + "\n");
                                        escribirequipos.write(listae.get(j).getJ().get(l).getEdad() + "\n");
                                        escribirequipos.write(listae.get(j).getJ().get(l).getNombre_jug() + "\n");
                                    }
                                }
                            }

                        } catch (FileNotFoundException ex) {
                            System.out.println(ex.getLocalizedMessage());
                        }
                     //   break;
                  //  case 3:
                        System.out.println("Ha salido.");
                   // default:

                    //    System.out.println("Introduzca una opcion especificada porfavor.");
                   //     break;

               // }

           // }

          //  if (option == 3) {
                System.out.println("COMIENZA LA LIGA\n Primer partido: ");
                Partido partid = new Partido();

                Arbitraje arbitr = new Arbitraje();
                System.out.println("NOMNBRE ARBITRO: " + arbitr.getArbitro_principal().getNombre_arbitro() + "\n NOMBRE DERECHO:" + arbitr.getLinier_dere().getNombre_arbitro() + "\nNOMBRE IZQUIERDA: " + arbitr.getLinier_izq().getNombre_arbitro());
                escribirarbitro.write(arbitr.getArbitro_principal().getNombre_arbitro() + "\n");
                escribirarbitro.write(arbitr.getLinier_dere().getNombre_arbitro() + "\n");
                escribirarbitro.write(arbitr.getLinier_izq().getNombre_arbitro() + "\n");
                escribirarbitro.close();
                int cont = 0;//cont2=0;
                perdedordata.writeUTF("\nPRIMERA RONDA\n");
                while (cont < aux) {

                    System.out.println("Partido n " + cont + ": \n ");
                    if (cont == aux) {
                        System.out.println("Fin partidos");
                    } else {
                        System.out.println("(" + this.listae.get(cont).getNombre_equipo() + "),(" + this.listae.get(cont + 1).getNombre_equipo() + ")");

                        ///////////////////////////////////////////////////////////////
                        //                                                           //
                        //  AQUI SE APLICA EL METODO comprobarNacionalidad, DONDE SE //
                        //  COMPRUBEBA QUE EL ARBITRO SEA DE DISTINTA NACIONALIDAD   //
                        //  QUE EL CLUB                                              //
                        //                                                           //
                        ///////////////////////////////////////////////////////////////
                        comprobaraNacionalidad(listae, arbitr, cont);
                       

                        partid.jugarPartido(this.listae.get(cont), this.listae.get(cont + 1));
                        CiudadPartido c2 = new CiudadPartido("Paris","Francia","Estadio 2","Calle estadio 2");
                        escribir_ciu_lig.write(c2.getNombre_ciudad()+"\n");
                        escribir_ciu_lig.write(c2.getNombre_pais()+"\n");
                        escribir_ciu_lig.write(c2.getNombre_ciudad_estadio()+"\n");
                        escribir_ciu_lig.write(c2.getNombre_pais()+"\n");
                        if (this.listae.get(cont).getPartidos_ganados() > this.listae.get(cont + 1).getPartidos_ganados()) {
                            System.out.println("Ganador el equipo: " + listae.get(cont).getNombre_equipo() + " con (" + listae.get(cont).getPartidos_ganados() + ")");
                            this.ganadores1.add(listae.get(cont));
                            
                            
                            perdedordata.writeUTF(listae.get(cont+1).getnombre_equipo());
                            perdedordata.writeUTF(listae.get(cont + 1).getCiudad());
                            perdedordata.writeUTF(listae.get(cont + 1).getPais());
                            perdedordata.writeInt(listae.get(cont + 1).getNum_goles());
                            perdedordata.writeUTF(listae.get(cont + 1).getNombre_estadio());
                            perdedordata.writeUTF(listae.get(cont + 1).getFecha_fundacion());
                            perdedordata.writeInt(listae.get(cont + 1).getPartidos_ganados());
                            perdedordata.writeUTF("\n\n");
                            // primera_ronda_string[cont2]=listae.get(cont).nombre_equipo.toString()+" con "+listae.get(cont).getPartidos_ganados()+" goles.";
                            // cont2++;
                        }
                        if (this.listae.get(cont).getPartidos_ganados() < this.listae.get(cont + 1).getPartidos_ganados()) {
                            System.out.println("Ganador el equipo: " + listae.get(cont + 1).getNombre_equipo() + " con (" + listae.get(cont + 1).getPartidos_ganados() + ")");
                            this.ganadores1.add(listae.get(cont+1));
                            
                            
                            
                            perdedordata.writeUTF(listae.get(cont).getnombre_equipo());
                            perdedordata.writeUTF(listae.get(cont).getCiudad());
                            perdedordata.writeUTF(listae.get(cont).getPais());
                            perdedordata.writeInt(listae.get(cont).getNum_goles());
                            perdedordata.writeUTF(listae.get(cont).getNombre_estadio());
                            perdedordata.writeUTF(listae.get(cont).getFecha_fundacion());
                            perdedordata.writeInt(listae.get(cont).getPartidos_ganados());
                            perdedordata.writeUTF("\n\n");
                            //   primera_ronda_string[cont2]=listae.get(cont+1).nombre_equipo.toString()+" con "+listae.get(cont+1).getPartidos_ganados()+" goles.";
                            //  cont2++;
                            
                        }
                        Partido part = new Partido();
                        part.setNum_partido(aux);
                        part.setN_equiplocal(listae.get(cont).getNombre_equipo());
                        cont += 2;

                    }
                }

                cont = 0;

                int count = 0;
                // while(cont < aux){ 
                for (int l = 0; l < aux; l++) {
                    if (this.listae.get(l).getPartidos_ganados() > 0) {
                        partid.getSegunda_ronda().add(this.listae.get(l));
                        //  System.out.println("Lista segunda ronda 2: "+partid.segunda_ronda.get(count).nombre_equipo);
                        count++;
                    }
                    //  cont+=2;
                }
                //  cont2=0;
                aux = aux / 2;
                count = 0;
                System.out.println("SEMIFINAL: ");
                ///////////////////////////////////////////////////////////////
                //                                                           //
                //  AQUI SE APLICA EL METODO comprobarNacionalidad, DONDE SE //
                //  COMPRUBEBA QUE EL ARBITRO SEA DE DISTINTA NACIONALIDAD   //
                //  QUE EL CLUB                                              //
                //                                                           //
                ///////////////////////////////////////////////////////////////

                comprobaraNacionalidad(partid.getSegunda_ronda(), arbitr, cont);
                perdedordata.writeUTF("\nSEGUNDA RONDA\n");
                while (cont < aux) {
                    partid.jugarPartido(partid.getSegunda_ronda().get(cont), partid.getSegunda_ronda().get(cont+1));
                       CiudadPartido c3 = new CiudadPartido("Roma","Italia","Estadio 3","Calle estadio 3");
                    escribir_ciu_lig.write("\n"+c3.getNombre_ciudad());
                    escribir_ciu_lig.write("\n"+c3.getNombre_pais());
                    escribir_ciu_lig.write("\n"+c3.getNombre_ciudad_estadio());
                    escribir_ciu_lig.write("\n"+c3.getNombre_pais()+"\n");     
                    if (partid.getSegunda_ronda().get(cont).getPartidos_ganados() > partid.getSegunda_ronda().get(cont + 1).getPartidos_ganados()) {
                        partid.getTercera_ronda().add(partid.getSegunda_ronda().get(cont));
                        System.out.println("----Ganador: " + partid.getSegunda_ronda().get(count).getPartidos_ganados() + " con " + partid.getSegunda_ronda().get(count).getPartidos_ganados());
                          this.ganadores2.add(partid.getSegunda_ronda().get(count));
 
                        
                        
                        
                        
                        perdedordata.writeUTF(partid.getSegunda_ronda().get(count+1).getnombre_equipo());
                            perdedordata.writeUTF(partid.getSegunda_ronda().get(count+1).getCiudad());
                            perdedordata.writeUTF(partid.getSegunda_ronda().get(count+1).getPais());
                            perdedordata.writeInt(partid.getSegunda_ronda().get(count+1).getNum_goles());
                            perdedordata.writeUTF(partid.getSegunda_ronda().get(count+1).getNombre_estadio());
                            perdedordata.writeUTF(partid.getSegunda_ronda().get(count+1).getFecha_fundacion());
                            perdedordata.writeInt(partid.getSegunda_ronda().get(count+1).getPartidos_ganados());
                            perdedordata.writeUTF("\n\n");                        
//     segunda_ronda_string[cont2]=partid.segunda_ronda.get(cont).nombre_equipo+" con "+partid.segunda_ronda.get(cont).getPartidos_ganados()+"goles.";
                    } else {
                        partid.getTercera_ronda().add(partid.getSegunda_ronda().get(cont));
                        System.out.println("----Ganador: " + partid.getTercera_ronda().get(count).getPartidos_ganados() + " con " + partid.getSegunda_ronda().get(count).getPartidos_ganados());
                        this.ganadores2.add(partid.getSegunda_ronda().get(count+1));    
                        
                        
                        perdedordata.writeUTF(partid.getSegunda_ronda().get(count).getnombre_equipo());
                            perdedordata.writeUTF(partid.getSegunda_ronda().get(count).getCiudad());
                            perdedordata.writeUTF(partid.getSegunda_ronda().get(count).getPais());
                            perdedordata.writeInt(partid.getSegunda_ronda().get(count).getNum_goles());
                            perdedordata.writeUTF(partid.getSegunda_ronda().get(count).getNombre_estadio());
                            perdedordata.writeUTF(partid.getSegunda_ronda().get(count).getFecha_fundacion());
                            perdedordata.writeInt(partid.getSegunda_ronda().get(count).getPartidos_ganados());
                            perdedordata.writeUTF("\n\n");    
                            
                        //     segunda_ronda_string[cont2]=partid.segunda_ronda.get(cont+1).nombre_equipo+" con "+partid.segunda_ronda.get(cont+1).getPartidos_ganados()+"goles.";
                    }
                    cont += 2;
                    count++;
                }
                
                try {

                    escribirarbitro.write(arbitr.getArbitro_principal().getNombre_arbitro());
                    escribirarbitro.close();
                    
                    for (int i = 0; i < 7; i++) {
                        escribirarbitro.write(listae.get(i).getNombre_equipo());
                        escribirarbitro.close();
                    }
                } catch (IOException ex) {
                    ex.getLocalizedMessage();
                }

                aux = aux / 2;
                cont = 0;
                int cont_fin = 0;
                System.out.println("FINAL: ");
                ///////////////////////////////////////////////////////////////
                //                                                           //
                //  AQUI SE APLICA EL METODO comprobarNacionalidad, DONDE SE //
                //  COMPRUBEBA QUE EL ARBITRO SEA DE DISTINTA NACIONALIDAD   //
                //  QUE EL CLUB                                              //
                //                                                           //
                ///////////////////////////////////////////////////////////////

                comprobaraNacionalidad(partid.getTercera_ronda(), arbitr, cont);
                perdedordata.writeUTF("\nFINAL\n");
                while (cont < aux) {
                    System.out.println("Partido: " + partid.getTercera_ronda().get(cont).getNombre_equipo() + " contra " + partid.getTercera_ronda().get(cont + 1).getNombre_equipo());
                    partid.jugarPartido(partid.getTercera_ronda().get(cont), partid.getTercera_ronda().get(cont + 1));
                    CiudadPartido c1 = new CiudadPartido("Valladolid","España","Estadio 1","Calle estadio1");
                    escribir_ciu_lig.write("\n"+c1.getNombre_ciudad());
                    escribir_ciu_lig.write("\n"+c1.getNombre_pais());
                    escribir_ciu_lig.write("\n"+c1.getNombre_ciudad_estadio());
                    escribir_ciu_lig.write("\n"+c1.getNombre_pais()+"\n");
                    if (partid.getTercera_ronda().get(cont).getPartidos_ganados() > 2) {
                        partid.getFinal_ronda().add(partid.getTercera_ronda().get(cont));
                        Ganador = partid.getFinal_ronda().get(0).getNombre_equipo();
                        System.out.println("GANADOR DEL TORNEO: " + partid.getFinal_ronda().get(cont_fin).getNombre_equipo());
                         perdedordata.writeUTF(partid.getSegunda_ronda().get(cont+1).getnombre_equipo());
                            perdedordata.writeUTF(partid.getTercera_ronda().get(cont+1).getCiudad());
                            perdedordata.writeUTF(partid.getTercera_ronda().get(cont+1).getPais());
                            perdedordata.writeInt(partid.getTercera_ronda().get(cont+1).getNum_goles());
                            perdedordata.writeUTF(partid.getTercera_ronda().get(cont+1).getNombre_estadio());
                            perdedordata.writeUTF(partid.getTercera_ronda().get(cont+1).getFecha_fundacion());
                            perdedordata.writeInt(partid.getTercera_ronda().get(cont+1).getPartidos_ganados());
                            perdedordata.writeUTF("\n\n");
                    } else {
                        partid.getFinal_ronda().add(partid.getTercera_ronda().get(cont + 1));
                        Ganador = partid.getFinal_ronda().get(0).getNombre_equipo();
                        System.out.println("GANADOR DEL TORNEO: " + partid.getFinal_ronda().get(cont_fin).getNombre_equipo());
                        perdedordata.writeUTF(partid.getTercera_ronda().get(cont).getCiudad());
                            perdedordata.writeUTF(partid.getTercera_ronda().get(cont).getPais());
                            perdedordata.writeInt(partid.getTercera_ronda().get(cont).getNum_goles());
                            perdedordata.writeUTF(partid.getTercera_ronda().get(cont).getNombre_estadio());
                            perdedordata.writeUTF(partid.getTercera_ronda().get(cont).getFecha_fundacion());
                            perdedordata.writeInt(partid.getTercera_ronda().get(cont).getPartidos_ganados());
                    }
                    cont_fin++;
                    cont += 2;
                }
           // }
            perdedordata.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    /*
        cont=0;
        count = 0;
            partid.jugarPartido(partid.final_ronda.get(cont), partid.final_ronda.get(cont+1));
            if (partid.final_ronda.get(cont).partidos_ganados>partid.final_ronda.get(cont+1).partidos_ganados) {
                System.out.println("GANADOR: "+partid.final_ronda.get(cont).nombre_equipo.toUpperCase()+".");
            }else{
                System.out.println("GANADOR: "+partid.final_ronda.get(cont+1).nombre_equipo.toUpperCase()+".");
            }
     */
    public void comprobaraNacionalidad(ArrayList<Clubfutbol> a, Arbitraje b, int cont) {
        boolean correcto = false;
        while (correcto == false) {
            if (b.getArbitro_principal().getNacionalidad_arbitro().equals(a.get(cont).getNacionalidad())) {

                try {
                    Arbitro nuevo = new Arbitro();
                    b.setArbitro_principal(nuevo);

                    throw new ArbitroException();
                } catch (ArbitroException ex) {
                    System.out.println(ex.toString());
                }

            } else if (b.getArbitro_principal().getNacionalidad_arbitro().equals(a.get(cont + 1).getNacionalidad())) {
                try {
                    System.out.println("La nacionalidad del equipo y la del arbitro coinciden. Se cambiará el arbitro.");
                    Arbitro nuevo = new Arbitro();
                    b.setArbitro_principal(nuevo);
                    throw new ArbitroException();
                } catch (ArbitroException ex) {
                    System.out.println(ex.toString());
                }

            } else {
                System.out.println("Nacionalidades correctas, se procede al partido.");
                correcto = true;
            }
        }
        System.out.println("TODO CORRECTO");
    }

    public String getNombrelig() {
        return nombrelig;
    }

    public void setNombrelig(String nombrelig) {
        this.nombrelig = nombrelig;
    }

    public int getNumequip() {
        return numequip;
    }

    public void setNumequip(int numequip) {
        this.numequip = numequip;
    }

    public ArrayList<Clubfutbol> getListae() {
        return listae;
    }

    public void setLista_equip(ArrayList<Clubfutbol> listae) {
        this.listae = listae;
    }

    

    /*
    public String toString(){
        if (!"".equals(Ganador)) {
        return "Nombre liga: "+this.nombrelig+"\nTotal equipos: "+this.numequip+"\nGanador de la liga: "+this.Ganador+"\n-------------------------\nRondas\nPrimera ronda ganadores: \n"
                + primera_ronda_string[0]+","+primera_ronda_string[1]+","+primera_ronda_string[2]+","+primera_ronda_string[3]+"\nSegunda ronda ganadores: \n"+segunda_ronda_string[0]+","+segunda_ronda_string[1]+".\n";    
        }else{
            return "Denbe crear y jugar una liga primero.";
        }
        
    }
     */
    public Scanner getSc() {
        return sc;
    }

    public void setSc(Scanner sc) {
        this.sc = sc;
    }

    public String getGanador() {
        return Ganador;
    }

    public void setGanador(String Ganador) {
        this.Ganador = Ganador;
    }

    public ArrayList<Arbitraje> getLista_arbitraje() {
        return lista_arbitraje;
    }

    public void setLista_arbitraje(ArrayList<Arbitraje> lista_arbitraje) {
        this.lista_arbitraje = lista_arbitraje;
    }

    public ArrayList<CiudadPartido> getCiudad_part() {
        return Ciudad_part;
    }

    public void setCiudad_part(ArrayList<CiudadPartido> Ciudad_part) {
        this.Ciudad_part = Ciudad_part;
    }

    public ArrayList<Clubfutbol> getGanadores1() {
        return ganadores1;
    }

    public void setGanadores1(ArrayList<Clubfutbol> ganadores1) {
        this.ganadores1 = ganadores1;
    }

    public ArrayList<Clubfutbol> getGanadores2() {
        return ganadores2;
    }

    public void setGanadores2(ArrayList<Clubfutbol> ganadores2) {
        this.ganadores2 = ganadores2;
    }


   

   

}
