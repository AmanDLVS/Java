/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_amancio_interfaz;

import javax.swing.JFrame;

/**
 *
 * @author amanc
 */
public class Campo_futbol extends JFrame{
 
    public Campo_futbol(){
        super("Imagen");
        setSize(500,500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
