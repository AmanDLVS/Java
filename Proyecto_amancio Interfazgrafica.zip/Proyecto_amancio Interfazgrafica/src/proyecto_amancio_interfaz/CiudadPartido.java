/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_amancio_interfaz;

/**
 *
 * @author amanc
 */
public class CiudadPartido extends Ciudad{
    private String nombre_ciudad_estadio; 
    private String direccion_estadio; 
    CiudadPartido(String nc,String np,String n,String d){
        super(nc,np);
        this.nombre_ciudad_estadio=n;
        this.direccion_estadio=d;
    }

    public String getNombre_ciudad_estadio() {
        return nombre_ciudad_estadio;
    }

    public void setNombre_ciudad_estadio(String nombre_ciudad_estadio) {
        this.nombre_ciudad_estadio = nombre_ciudad_estadio;
    }

    public String getDireccion_estadio() {
        return direccion_estadio;
    }

    public void setDireccion_estadio(String direccion_estadio) {
        this.direccion_estadio = direccion_estadio;
    }

    @Override
    public String toString() {
        return "CiudadPartido{" + "nombre_ciudad_estadio=" + nombre_ciudad_estadio + ", direccion_estadio=" + direccion_estadio + '}';
    }
    
    
}
