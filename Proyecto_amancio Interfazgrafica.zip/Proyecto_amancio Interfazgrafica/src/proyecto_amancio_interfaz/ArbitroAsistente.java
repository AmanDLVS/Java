/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_amancio_interfaz;

/**
 *
 * @author amanc
 */
public class ArbitroAsistente extends Arbitro{
    private String posicion;

    
    public ArbitroAsistente() {
        this.posicion = linier();
    }

    public ArbitroAsistente(String posicion) {
        this.posicion = posicion;
    }
    public String nomLinier() {
        int p = (int) (Math.random() * (8 + 1));
        String nombres[] = {"Mateo", "Leo", "Daniel", "Alejandro", "Pablo", "Manuel", "Alvaro", "Adrian", "David"};
        return nombres[p];
    }
    public String nacLinier() {
        int n = (int) (Math.random() * (6 + 1));
        String nacionalidades[] = {"Egipto", "PORTUGAL", "FRANCIA", "ITALIA","Congo","Ruso","Chino"};
        return nacionalidades[n];

    }
    public void datosLinier(ArbitroAsistente e){
        e.setNombre_arbitro(nomLinier());
        e.setNacionalidad_arbitro(nacLinier());
    }

    public String linier(){
        int n = (int) (Math.random() * (1 + 1) );
        if (n==1) {
            return "linier izquierdo";
        }else{
            return "linier derecho";
        }
    }
    
    
    
}
